#include <stdio.h>

int main()
{
	printf("Nam Jonghyeon\n");
	return 0;
}
